﻿//using UnityEngine;
//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine.UI;

//// this is the master game script, attached to th ebow

//public class bowAndArrow : MonoBehaviour
//{
//    public GameObject right;
//    public GameObject left;
//    public GameObject midel;
//    public GameObject lastpossition;
//    public bool GameOver;
//    public bool GameWin;
//    public GameObject GameOverPanel;
//    public GameObject GameWinPanel;

//    public ScoreManager scoreManager;
//    private bool BallClicked;


//    private bool check;
//    public Image star1;
//    public Image star2;
//    public Image star3;


//    public GameObject level1;
//    public GameObject level2;
//    public GameObject level3;
//    public GameObject level4;
//    public GameObject level5;
//    public GameObject level6;

//    private int CurrentGameLevel;
//    public Sprite Sprite_level1;
//    public Sprite Sprite_level2;
//    public Sprite Sprite_level3;
//    public Sprite Sprite_level4;
//    public Sprite Sprite_level5;
//    public Sprite Sprite_level6;

//    public Material Level1Material;
//    public Material Level2Material;
//    //public Material Level3Material;
//    //public Material Level4Material;
//    //public Material Level5Material;
//    //public Material Level6Material;
//    // to determine the mouse position, we need a raycast
//    private Ray mouseRay1;
//    private RaycastHit rayHit;
//    // position of the raycast on the screen
//    private float posX;
//    private float posY;

//    // References to the gameobjects / prefabs
//    public GameObject bowString;
//    GameObject arrow;
//    public GameObject arrowPrefab;
//    public GameObject gameManager;
//    public GameObject risingText;
//    //public GameObject target;
//    public SpriteRenderer Spriterenderer;


//    // the bowstring is a line renderer
//    private List<Vector3> bowStringPosition;
//    LineRenderer bowStringLinerenderer;

//    // to determine the string pullout
//    float arrowStartX;
//    float length1;
//    float length2;
//    // some status vars
//    bool arrowShot;
//    bool arrowPrepared;

//    Vector3 stringPullout;
//    Vector3 stringRestPosition = new Vector3(0f, 1.8f, 0f);

//    public GameObject camera9;


//    public int arrows = 3;
//    // actual score
//    public int score = 0;


//    //
//    // void resetGame()
//    //
//    // this method resets the game status
//    //

//    void resetGame()
//    {
//        arrows = 3;
//        score = 0;
//        if (GameObject.Find("arrow") == null)
//            createArrow();
//    }

//    public void NextLevel(){

//        if (CurrentGameLevel==1){
//            level1.SetActive(false);
//            level2.SetActive(true);
//            Spriterenderer.sprite = Sprite_level1;
//            arrows = 3;
//            //CurrentGameLevel++;
//            // PlayerPrefs.SetInt("CurrentLevel", 2);
//        }
//        else if(CurrentGameLevel==2){
//            level1.SetActive(false);
//            level2.SetActive(true);
//            Spriterenderer.sprite = Sprite_level2;
//            arrows = 3;
//            //CurrentGameLevel++;
//            // PlayerPrefs.SetInt("CurrentLevel", 3);
//        }
//        else if (CurrentGameLevel == 3)
//        {
//            level2.SetActive(false);
//            level3.SetActive(true);
//            Spriterenderer.sprite = Sprite_level3;
//            arrows = 3;
//            // CurrentGameLevel++;
//            // PlayerPrefs.SetInt("CurrentLevel", 4);
//        }
//        else if (CurrentGameLevel == 4)
//        {
//            level3.SetActive(false);
//            level4.SetActive(true);
//            Spriterenderer.sprite = Sprite_level4;
//            arrows = 3;
//            //  CurrentGameLevel++;
//            //  PlayerPrefs.SetInt("CurrentLevel", 5);
//        }
//        else if (CurrentGameLevel == 5)
//        {
//            level4.SetActive(false);
//            level5.SetActive(true);
//            Spriterenderer.sprite = Sprite_level5;
//            arrows = 3;
//            //  CurrentGameLevel++;
//            //  PlayerPrefs.SetInt("CurrentLevel", 6);
//        }
//        else if (CurrentGameLevel == 6)
//        {
//            level5.SetActive(false);
//            level6.SetActive(true);
//            Spriterenderer.sprite = Sprite_level6;
//            arrows = 3;
//        }
//    }

//    public void MoveButtonPressed()
//    {
//        BallClicked = true;
//    }
//    public void MoveButtonReleased()
//    {
//        BallClicked = false;
//    }



//    public void ChangeGameOverState(){
//        GameOver = GameOver ? false : true;
//        }
//    public void ChangeGameWinState()
//    {
//        scoreManager.Score();
//        GameWin = GameWin ? false : true;
//    }

//    public void LevelUp(){
//        CurrentGameLevel++;
//        PlayerPrefs.SetInt("Levels", CurrentGameLevel);
//    }

   

//    public void CurrentLevel(){
//        CurrentGameLevel = 0;
//    }

//    // Use this for initialization
//    void Start()
//    {
//  //      Debug.Log(arrows + "ss");
//        GameOver = false;
//        GameWin = false;
//        check = true;



//        CurrentGameLevel = PlayerPrefs.GetInt("CurrentLevel", 1);
//        if(CurrentGameLevel==6){
//            level6.SetActive(true);
//        }
//        else if(CurrentGameLevel == 5){
//            level5.SetActive(true);
//        }
//        else if (CurrentGameLevel == 4)
//        {
//            level4.SetActive(true);
//        }
//        else if (CurrentGameLevel == 3)
//        {
//            level3.SetActive(true);
//        }
//        else if (CurrentGameLevel == 2)
//        {
//            level2.SetActive(true);
//        }
//        else
//        {
//            level1.SetActive(true);
//        }

//        // create the PlayerPref
//       // initScore();

//        // create an arrow to shoot
//        // use true to set the target
//        createArrow();

//        // setup the line renderer representing the bowstring
//        bowStringLinerenderer = bowString.AddComponent<LineRenderer>();
//        bowStringLinerenderer.SetVertexCount(5);
//        bowStringLinerenderer.SetWidth(0.15f, 0.15f);
//        bowStringLinerenderer.useWorldSpace = false;
//        bowStringLinerenderer.material = Resources.Load("Materials/bowStringMaterial") as Material;
//        bowStringPosition = new List<Vector3>();
//        bowStringPosition.Add(right.transform.position);
//        bowStringPosition.Add(new Vector3(0f, -0.06f, 2f));
//        bowStringPosition.Add(new Vector3(0.1f, -0.06f, 2f));
//        bowStringPosition.Add(new Vector3(-0.1f, -0.06f, 2f));
//        bowStringPosition.Add(left.transform.position);
//        bowStringLinerenderer.SetPosition(0, bowStringPosition[0]);
//        bowStringLinerenderer.SetPosition(1, bowStringPosition[1]);
//        bowStringLinerenderer.SetPosition(2, bowStringPosition[2]);
//        bowStringLinerenderer.SetPosition(3, bowStringPosition[3]);
//        bowStringLinerenderer.SetPosition(4, bowStringPosition[4]);
//        arrowStartX =1f;

//        stringPullout = stringRestPosition;
//    }



//    // Update is called once per frame
//    void Update()
//    {
//    //    Debug.Log("lenghmmmmmmmmt1=========" + midel.transform.position.y);
//   //     Debug.Log("lassssssss" + lastpossition.transform.localPosition.y);
//        //        Debug.Log(arrows + "aaaaaa");
//        if (GameOver)
//        {
//            GameOverPanel.SetActive(true);
//        }
//        else if(GameWin){
//            GameWinPanel.SetActive(true);
//        }
//        // check the game states

//        // leave the game when back key is pressed (android)
//        if (Input.GetKeyDown(KeyCode.Escape))
//        {
//            Application.Quit();
//        }

//        // game is steered via mouse
//        // (also works with touch on android)
//        if (Input.GetMouseButton(0)&& !GameOver && !GameWin)
//        {

//            // detrmine the pullout and set up the arrow
//            prepareArrow();
//        }

//        // ok, player released the mouse
//        // (player released the touch on android)
//        if (Input.GetMouseButtonUp(0) && arrowPrepared)
//        {
//            Debug.Log("gfdsgdf");
//            // shot the arrow (rigid body physics)
//            shootArrow();
//        }
//        // in any case: update the bowstring line re  nderer
//        drawBowString();

//        if(arrows == 0 && check){
//            if (!GameWin)
//            {
//                ChangeGameOverState();
//                check = false;
//            }
//        } 
//    }



//    //
//    // public void initScore()
//    //
//    // The player score is stored via Playerprefs
//    // to make sure they can be stored,
//    // they have to be initialized at first
//    //

//    public void initScore()
//    {
//        if (!PlayerPrefs.HasKey("Score"))
//            PlayerPrefs.SetInt("Score", 0);
//    }


//    public void Replay(){
//        arrows = 3;
//        check = true;
//       // ChangeGameOverState();
//    }

//    //
//    // public void createArrow()
//    //
//    // this method creates a new arrow based on the prefab
//    //

//    public void createArrow()
//    {
       
//        // when a new arrow is created means that:
//        // does the player has an arrow left ?
//        if (arrows > 0)
//        {
//            // may target's position be altered?

//            // now instantiate a new arrow
//            this.transform.localRotation = Quaternion.identity;
//            arrow = Instantiate(arrowPrefab, Vector3.zero, Quaternion.identity) as GameObject;
//            arrow.name = "arrow";

//            arrow.GetComponent<Renderer>().material = Level2Material;
//            //rand.material = Level2Material;
//            arrow.transform.localScale = new Vector3(0.7F, 0.7f, 0.7f);
//            arrow.transform.localPosition = this.midel.transform.position ;
//            arrow.transform.localRotation = this.transform.localRotation;
//            arrow.transform.parent = this.transform;
//           // arrow.AddComponent<SphereCollider>();
//            // transmit a reference to the arrow script
//            arrow.GetComponent<rotateArrow>().setBow(gameObject);
//            arrow.GetComponent<rotateArrow>().Setcamera(camera9);
//            arrowShot = false;
//            arrowPrepared = false;
//            // subtract one arrow
//            arrows--;
//        }
//        else
//        {

//        }
//    }


//    //
//    // public void shootArrow()
//    //
//    // Player released the arrow
//    // get the bows rotationn and accelerate the arrow
//    //

//    public void shootArrow()
//    {
//        if (arrow.GetComponent<Rigidbody>() == null)
//        {
//            arrowShot = true;
//            arrow.AddComponent<Rigidbody>();
//          //  Debug.Log(posX);
//            arrow.GetComponent<Rigidbody>().angularDrag = 0.1f;
//            arrow.GetComponent<Rigidbody>().mass = 0.1f;
//            arrow.GetComponent<Rigidbody>().useGravity=false;
//            //  arrow.transform.parent = gameManager.transform;
//            if (posX > 0)
//                arrow.GetComponent<Rigidbody>().AddForce(Quaternion.Euler(new Vector3(transform.rotation.eulerAngles.x, 0, 0)) * new Vector3(12f * -posX, -posY*4f, 0), ForceMode.VelocityChange);
//            else if(posX < 0)
//                arrow.GetComponent<Rigidbody>().AddForce(Quaternion.Euler(new Vector3(transform.rotation.eulerAngles.x, 0, 0)) * new Vector3(12f * -posX, -posY*4f, 0), ForceMode.VelocityChange);

//            //  arrow.GetComponent<Rigidbody>().AddForce(transform.forward * 15f);
//        }
//        arrowPrepared = false;
//        stringPullout = stringRestPosition;

//        // Cam
       

//    }

//    public void prepareArrow()
//    {
//        //if(BallClicked)
//        mouseRay1 = Camera.main.ScreenPointToRay(Input.mousePosition);
//        if (Physics.Raycast(mouseRay1, out rayHit, 100f) && arrowShot == false)
//        {
//            // determine the position on the screen
//            posX = this.rayHit.point.x;
//            posY = this.rayHit.point.y;
//            // set the bows angle to the arrow
//            Vector2 mousePos = new Vector2(transform.position.x - posX, transform.position.y - posY);
//           float angleZ = Mathf.Atan2(mousePos.y, mousePos.x) ;
//            transform.eulerAngles = new Vector3(0, 0, 0);
//            // determine the arrow pullout
//            length1 = mousePos.magnitude/ 30f;
//           // length2 = mousePos.y / 15f;
//            //length1 = Mathf.Clamp(length1, 0, 0.5f);
//          // length2 = Mathf.Clamp(0, length2, 1);
//            //Debug.Log("lenghmmmmmmmmt1========="+ midel.transform.position.y);
//            //Debug.Log("lassssssss" + lastpossition.transform.position.y);
//        //   Debug.Log("mouse" + mousePos.y);
//            // set the bowstrings line renderer
//            if (mousePos.y > midel.transform.position.y )
//            {
//                //Debug.Log("mouse" + mousePos.y);
//                //  Debug.Log("lenghmmmmmmmmt1=========" + midel.transform.position.y);
//               // if (mousePos.y < lastpossition.transform.position.y)
//                    stringPullout = new Vector3(-mousePos.x, -mousePos.y, -2f);
//            }
//            if (mousePos.y < lastpossition.transform.position.y)
//            {
//                //Debug.Log("mouse" + mousePos.y)
//                //Debug.Log("lassssssss" + lastpossition.transform.position.y);
//            }
//                // set the arrows position
//            Vector3 arrowPosition = stringPullout;
//            arrowPosition.y = ( arrowPosition.y+0.5f);
//            arrow.transform.localPosition = arrowPosition;
//            arrow.transform.rotation = Quaternion.Euler(0, 0, angleZ);
//           // Debug.Log(arrow.transform.rotation);
//        }
//        arrowPrepared = true;
//    }



//    //
//    // public void drawBowString()
//    //
//    // set the bowstrings line renderer position
//    //

//    public void drawBowString()
//    {
//        bowStringLinerenderer = bowString.GetComponent<LineRenderer>();
//        bowStringLinerenderer.SetPosition(0, bowStringPosition[0]);
//        bowStringLinerenderer.SetPosition(1, new Vector3(stringPullout.x - 0.1f, stringPullout.y, stringPullout.z));
//        bowStringLinerenderer.SetPosition(2, stringPullout);
//        bowStringLinerenderer.SetPosition(3, new Vector3(stringPullout.x + 0.1f, stringPullout.y, stringPullout.z));
//        bowStringLinerenderer.SetPosition(4, bowStringPosition[4]);
//    }



//    public void setPoints(int points)
//    {
//        score += points;
//        if (points == 50)
//        {
//            arrows++;
//            GameObject rt1 = (GameObject)Instantiate(risingText, new Vector3(0, 0, 0), Quaternion.identity);
//            rt1.transform.position = this.transform.position + new Vector3(0, 0, 0);
//            rt1.transform.name = "rt1";
//            // each target's "ring" is 0.07f wide
//            // so it's relatively simple to calculate the ring hit (thus the score)
//            rt1.GetComponent<TextMesh>().text = "Bonus arrow";
//        }
//    }


//}