﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveObstacal_L4 : MonoBehaviour {
    public GameObject Obstacal;
    float maxValue = 2; // or whatever you want the max value to be
    float minValue = -2; // or whatever you want the min value to be
    float currentValue = 0; // or wherever you want to start
    int direction = 1;
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        currentValue += Time.deltaTime * direction;
        if (currentValue >= maxValue)
        {
            direction *= -1;
            currentValue = maxValue;
        }
        else if (currentValue <= minValue)
        {
            direction *= -1;
            currentValue = minValue;
        }
        Obstacal.transform.position = new Vector3(currentValue, 1.5f, 0);
    }
}
