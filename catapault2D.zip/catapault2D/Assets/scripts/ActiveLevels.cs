﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class ActiveLevels : MonoBehaviour {
    public Button[] LevelButtons;
    private int Levels;
	// Use this for initialization
	void Start () {
      //PlayerPrefs.SetInt("Levels", 1);
      Levels = PlayerPrefs.GetInt("Levels", 1);
        for (int i=Levels; i < LevelButtons.Length;i++){

            LevelButtons[i].interactable = !LevelButtons[i].interactable;
             
        }
	}

    public void SelectLevels(int levels){
       PlayerPrefs.SetInt("CurrentLevel", levels);
    }


}
