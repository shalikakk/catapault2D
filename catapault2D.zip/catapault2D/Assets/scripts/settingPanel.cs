﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class settingPanel : MonoBehaviour {
    public Button settings;
    public Animator anim;
    private bool clicked;
	// Use this for initialization
	void Start () {
        clicked = true;
        settings.onClick.AddListener(panelOpen);
	}

    private void panelOpen()
    {
        if (clicked)
        {
            anim.SetBool("clicked", true);
            clicked = false;
        }
        else{
            anim.SetBool("clicked", false);
            clicked = true;
        }
        }


}
