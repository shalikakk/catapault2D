﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class projecter : MonoBehaviour {
 //   public float stretchLimit = 3f;
 //   public LineRenderer catapultRight;
 //   public LineRenderer catapultLeft;

 //   private SpringJoint2D spring;
 //   private Transform slingshoot;
 //   private bool clickedOn;
 //   private Ray rayToMouse;
 //   private float stretchLimit2;
 //   // public Rigidbody2D rb;
 //   public Button m_YourFirstButton;
 //   void Awake()
 //   {
 //       spring = GetComponent<SpringJoint2D>();
 //       //rb = GetComponent<Rigidbody2D>();
 //       slingshoot = spring.connectedBody.transform;
 //       rayToMouse = new Ray(slingshoot.position, Vector3.zero);
 //       stretchLimit2 = stretchLimit * stretchLimit;
 //   }


 //   void Start () {
 //       m_YourFirstButton.onClick.AddListener(TaskOnClick);
 //       LineRendererSetup();
 //      // rayToMouse = new Ray(catapult.position, Vector2.zero); 
	//}
 //   void TaskOnClick()
 //   {
 //       spring.enabled = true;
 //       GetComponent<Rigidbody2D>().isKinematic = false;
 //       clickedOn = false;
 //   }


 //   void Update () {
 //       if(clickedOn){
 //           Dragging();
 //       }
	//}



    //void LineRendererSetup(){
    //    catapultRight.SetPosition(0, catapultRight.transform.position);
    //    catapultLeft.SetPosition(0, catapultLeft.transform.position);
    //}

    // void OnMouseDown()
    //{
    //    Debug.Log("sdfdsfsd");
    //    spring.enabled = false;
    //    clickedOn = true;
    //    }

    //private void OnMouseUp()
    //{
    //    spring.enabled = true;
    //    GetComponent<Rigidbody2D>().isKinematic=false;
    //    clickedOn = false;
    //    }

    //void Dragging()
    //{

    //    Vector3 mouseWorldPoin = Camera.main.ScreenToWorldPoint(Input.mousePosition);
    //    Vector2 slingToMouse = mouseWorldPoin - slingshoot.position;
    //    if(slingToMouse.sqrMagnitude > stretchLimit2){
    //        rayToMouse.direction = slingToMouse;
    //        mouseWorldPoin = rayToMouse.GetPoint(stretchLimit);
    //    }
    //    mouseWorldPoin.z = 0f;
    //     transform.position = mouseWorldPoin;
    //}
}
