﻿//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;
//using UnityEngine.UI;

//public class ScoreManager : MonoBehaviour {
//    public static int score;
//   // public bool TimeMode;
//   // private bool SportyMode;
//    public LoadScreen loadScreenOn;
//    public bowAndArrow bow;
//    public Animator star1;
//    public Animator star2;
//    public Animator star3;
//    // private bool PlaySound;
//    private Sprite fullStar;
//    private Sprite nonstar;
//    public Image s1;
//    public Image s2;
//    public Image s3;

//    //public Text ScoreBanner;
//    //public Text Greatings;
//    public Text GameWinPanelScore;
//    //public Text FirstScore;
//    //public Text SecoundScore;
//    //public Text ThirdScore;
//  //  public static int CurrentScoreMultiplier;
//    // Use this for initialization
//    private int Round;

//    private bool Check;

//    void Start () {
//        fullStar = Resources.Load<Sprite>("star");
//        nonstar = Resources.Load<Sprite>("nonstar");
//        //IPD.AppKey = "s5oliVas1tT82HY3FrRJuUMdC2GheUeH0C2jxcLz";
//        //IPD.AppSecret = "FFHHmFL17DKBxxP9zvrOqFvqixJPKvopa57wLTyT";
//        //IPD.VersionID = 35;
//        ////IPD.SDKMode = "sandbox";
//        //IPD.SDKMode = "live";

//        // PlaySound = true;
//        Check = true;
      
//    }

//    public void Score()
//    {
//        Round = bow.arrows+1;
//        Debug.Log(Round+"    r  ");
//        switch (Round)
//        {
//            case 1:
//                score = 1000;
//                s1.sprite = fullStar;
//                s2.sprite = nonstar;
//                s3.sprite = nonstar;
//                break;
//            case 2:
//                score = 2000;
//                s1.sprite = fullStar;
//                s2.sprite = fullStar;
//                s3.sprite = nonstar;
//                break;
//            case 3:
//                score = 3000;
//                s1.sprite = fullStar;
//                s2.sprite = fullStar;
//                s3.sprite = fullStar;
//                break;
//        }

//        GameWinPanelScore.text = score.ToString();
//        StartCoroutine(UploadPNG());

//    }
//    public void ScoreReset()
//    {
//        score = 0;
     
//    }

//    private void Update()
//    {
//        //if(score==3000){
//        //    star1.SetBool("first", true);
//        //    star2.SetBool("star2", true);
//        //    star3.SetBool("star3", true);
//        //}else if(score==2000){
//        //    star1.SetBool("first", true);
//        //    star2.SetBool("star2", true);
//        //}
//        //else if (score == 1000)
//        //{
//        //    star1.SetBool("first", true);
//        //}
//    }

//    private IEnumerator UploadPNG(){
//        yield return new WaitForSeconds(0.5f);
//        star1.SetBool("first", true);
//        yield return new WaitForSeconds(0.2f);
//        if(score==3000){
//            star2.SetBool("star2", true);
//            yield return new WaitForSeconds(0.2f);
//            star3.SetBool("star3", true);
//        }
//        else if(score == 2000)
//        {
//            star2.SetBool("star2", true);
//        }

//    }

//        //if (TimeMode)
//        //{
//        //    //Get Score From PlayerPrefs
//        //    First_HighScore = PlayerPrefs.GetInt("First_HIghScore_Time", 0);
//        //    Secound_HighScore = PlayerPrefs.GetInt("Secound_HIghScore_Time", 0);
//        //    Third_HighScore = PlayerPrefs.GetInt("Third_HIghScore_Time", 0);

//    //    if (First_HighScore <= Finalscore)
//    //    {
//    //        PlayerPrefs.SetInt("First_HIghScore_Time", Finalscore);

//    //        if (First_HighScore < Finalscore)
//    //        {
//    //            PlayerPrefs.SetInt("Secound_HIghScore_Time", First_HighScore);
//    //            PlayerPrefs.SetInt("Third_HIghScore_Time", Secound_HighScore);
//    //        }
//    //    }
//    //    else if (Secound_HighScore <= Finalscore)
//    //    {
//    //        PlayerPrefs.SetInt("Secound_HIghScore_Time", Finalscore);
//    //        if (Secound_HighScore < Finalscore)
//    //        {
//    //            PlayerPrefs.SetInt("Third_HIghScore_Time", Secound_HighScore);
//    //        }
//    //    }
//    //    else if (Third_HighScore < Finalscore)
//    //    {
//    //        PlayerPrefs.SetInt("Third_HIghScore_Time", Finalscore);
//    //    }

//    //    if (IPD.IsLoggedIn())
//    //    {
//    //        Dictionary<string, string> param = new Dictionary<string, string>();
//    //        param.Add("Time_Score1", Finalscore + "");
//    //        param.Add("Sporty_Score1", "0");
//    //        if (score == 13)
//    //        {
//    //            param.Add("Status", "Win");
//    //        }
//    //        else
//    //        {
//    //            param.Add("Status", "GameOver");
//    //        }
//    //        IPD.doSendData(param, gameObject);
//    //    }

//    //}

//    //else if (SportyMode)
//    //{
//    //    //Get Score From PlayerPrefs
//    //    First_HighScore = PlayerPrefs.GetInt("First_HIghScore_Sporty", 0);
//    //    Secound_HighScore = PlayerPrefs.GetInt("Secound_HIghScore_Sporty", 0);
//    //    Third_HighScore = PlayerPrefs.GetInt("Third_HIghScore_Sporty", 0);

//    //    if (First_HighScore <= Finalscore)
//    //    {
//    //        PlayerPrefs.SetInt("First_HIghScore_Sporty", Finalscore);
//    //        if (First_HighScore < Finalscore)
//    //        {
//    //            PlayerPrefs.SetInt("Secound_HIghScore_Sporty", First_HighScore);
//    //            PlayerPrefs.SetInt("Third_HIghScore_Sporty", Secound_HighScore);
//    //        }
//    //    }
//    //    else if (Secound_HighScore <= Finalscore)
//    //    {
//    //        PlayerPrefs.SetInt("Secound_HIghScore_Sporty", Finalscore);
//    //        if (Secound_HighScore < Finalscore)
//    //        {
//    //            PlayerPrefs.SetInt("Third_HIghScore_Sporty", Secound_HighScore);
//    //        }
//    //    }

//    //    else if (Third_HighScore < Finalscore)
//    //    {
//    //        PlayerPrefs.SetInt("Third_HIghScore_Sporty", Finalscore);
//    //    }


//    //    if (IPD.IsLoggedIn())
//    //    {

//    //        Dictionary<string, string> param = new Dictionary<string, string>();
//    //        param.Add("Time_Score1", "0");
//    //        param.Add("Sporty_Score1", Finalscore + "");
//    //        if (score == 13)
//    //        {
//    //            param.Add("Status", "Win");
//    //        }
//    //        else
//    //        {
//    //            param.Add("Status", "GameOver");
//    //        }
//    //        IPD.doSendData(param, gameObject);
//    //    }

//    //}
//}



