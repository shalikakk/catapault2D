﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class ChangeSoundImage : MonoBehaviour {

    private Sprite mute, unmute;
    public Image SoundImage;
    void Start()
    {
        mute = Resources.Load<Sprite>("mute");
        unmute = Resources.Load<Sprite>("unmute");
    }
    private void Update()
    {
      ChangeImage();
    }

    //chech sound mode
    public void ChangeSoundMode()
    {
        AudioManager.Instance.SoundMode();
    }


    //Change Sound Image
    public void ChangeImage()
    {
        if (!AudioManager.sound)
        {
            SoundImage.sprite = mute;

        }
        else if (AudioManager.sound)
        {
            SoundImage.sprite = unmute;
        }
    }

}
