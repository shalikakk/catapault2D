﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : MonoBehaviour {
   public AudioClip clickOn, clickOff, win, gameover;
  //public AudioSource BackgrounSoundSource;
  // public AudioSource SoundEffect;
    public static bool sound = true;
    private static AudioManager _instance;
    public static AudioManager Instance
    {
        get
        {
            return _instance;
        }
    }
    void Awake()
    {

        if (_instance != null)
        {
            Destroy(this.gameObject);
            return;
        }

        DontDestroyOnLoad(this.gameObject);
        _instance = this;
    }

    //Change Sound mode
    public void SoundMode()
    {
        if (sound)
        {
     //       BackgrounSoundSource.mute = true;
     //       SoundEffect.mute = true;
            sound = false;
        }
        else
        {
    //        BackgrounSoundSource.mute = false;
     //       SoundEffect.mute = false;
            sound = true;
        }
    }


    //Select Sound
    public void PlaySound(string clip)
    {
        switch (clip)
        {
            //case "clickOn":
            //    SoundEffect.PlayOneShot(clickOn);
            //    break;
            //case "clickOff":
            //    SoundEffect.PlayOneShot(clickOff);
            //    break;
            //case "gameover":
            //    SoundEffect.PlayOneShot(gameover);
            //    break;
            //case "win":
                //SoundEffect.PlayOneShot(win);
                //break;
        }
    }


    public void PlaySound()
    {
    //    BackgrounSoundSource.Play();
    }
    public void PauseSound()
    {
    //    BackgrounSoundSource.Pause();
    }

}
