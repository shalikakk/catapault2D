﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ChangeVibrateImage : MonoBehaviour {

    private Sprite vibrate, nonvibrate;
    public Image vibrateImage;
    private bool clicked;
    void Start()
    {
        vibrate = Resources.Load<Sprite>("vibration");
        nonvibrate = Resources.Load<Sprite>("vibration_mute");
    }
  

    //chech sound mode
    public void ChangeVibrationMode()
    {
        Handheld.Vibrate();
        if (clicked)
        {
            vibrateImage.sprite = nonvibrate;
            clicked = false;
        }
        else{
            vibrateImage.sprite = vibrate;
            clicked = true;
        }
    }

}
