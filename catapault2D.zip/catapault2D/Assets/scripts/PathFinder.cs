﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PathFinder : MonoBehaviour {
    public float initialvelocity=10.0f;
    public float timeResolution=0.02f;
    public float MAxTime = 10.0f;
    private LineRenderer lineRenderer;
	// Use this for initialization
	void Start () {
        lineRenderer = GetComponent<LineRenderer>();
	}
	
	// Update is called once per frame
	void Update () {
        Vector3 velocityVector = transform.forward * initialvelocity;
        lineRenderer.SetVertexCount((int)(MAxTime / timeResolution));
        int index = 0;

        Vector3 currentposition = transform.position;

        for (float t = 0.0f; t < MAxTime;t+=timeResolution){
            lineRenderer.SetPosition(index,currentposition);
            currentposition += velocityVector * timeResolution;
            index++;

        }	
	}
}
