﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour {

    //bool collisionOccurred;
    public GameObject catapault;
    // Use this for initialization
    void Start () {
		
	}

    //void OnTriggerEnter2D(CircleCollider2D col)
    //{
    //    catapault.GetComponent<catapault>().createArrow();
    //    if (col.transform.tag == "UpWall")
    //    {
    //        Debug.Log("kjhklj");
    //        Destroy(this.gameObject);
    //    }
    //}
    void OnCollisionEnter2D(Collision2D other)
    {
       // catapault.GetComponent<catapault>().createArrow();
        if (other.transform.tag == "UpWall")
        {
            Debug.Log("kjhklj");
            Destroy(this.gameObject);
        }

    }

    public void SetCatapault(GameObject _bow)
    {
        catapault = _bow;
    }

    }
