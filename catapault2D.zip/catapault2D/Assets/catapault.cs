﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class catapault : MonoBehaviour {
    public GameObject right;
    public GameObject left;
    public GameObject midel;
    //public GameObject lastpossition;
    public GameObject bowString;
    private List<Vector3> bowStringPosition;
    LineRenderer bowStringLinerenderer;
    public GameObject ParentBall;
    GameObject ball;
    //public GameObject yello;
    private bool ballshoot;
    private bool ballPrepared;
    private Rigidbody2D rb;
    //public Rigidbody2D rb2;
    private Vector2 mousePosition;

    public GameObject ballperfab;

    private float posX;
    private float posY;

    // Use this for initialization
    void Start () {
       // rb = yello.GetComponent<Rigidbody2D>();
        createArrow();
       
        bowStringLinerenderer = bowString.GetComponent<LineRenderer>();
        bowStringLinerenderer.SetVertexCount(3);
        bowStringLinerenderer.SetWidth(0.2f, 0.2f);
        bowStringLinerenderer.useWorldSpace = true;
       // bowStringLinerenderer.material = Resources.Load("Materials/bowStringMaterial") as Material;
        bowStringPosition = new List<Vector3>();
        bowStringPosition.Add(right.transform.position);
        bowStringPosition.Add(midel.transform.position);
        bowStringPosition.Add(left.transform.position);
        bowStringLinerenderer.SetPosition(0, bowStringPosition[0]);
        bowStringLinerenderer.SetPosition(1, bowStringPosition[1]);
        bowStringLinerenderer.SetPosition(2, bowStringPosition[2]);
        //   bowStringLinerenderer.SetPosition(3, bowStringPosition[3]);
        //  bowStringLinerenderer.SetPosition(4, bowStringPosition[4]);
        //Debug.Log(right.transform.localPosition);
        //Debug.Log(left.transform.localPosition);
        //Debug.Log(midel.transform.localPosition);

    }

    // Update is called once per frame
    void Update () {
       
        //ball.transform.position.z = 0f;
        if (Input.GetMouseButton(0) )//
        {

            // detrmine the pullout and set up the arrow
            prepareArrow();
        }
        if (Input.GetMouseButtonUp(0) && ballPrepared)
        {

            // shot the arrow (rigid body physics)
            shootBall();
        }

    }

    public void createArrow()
    {

        // when a new arrow is created means that:
        // does the player has an arrow left ?

        // may target's position be altered?
      //  Debug.Log(midel.transform.position);
            // now instantiate a new arrow
            this.transform.localRotation = Quaternion.identity;
            ball = Instantiate(ballperfab, Vector2.zero, Quaternion.identity) as GameObject;
            ball.name = "arrow";

            //arrow.GetComponent<Renderer>().material = Level2Material;
            //rand.material = Level2Material;
            ball.transform.localScale = new Vector3(0.01F, 0.01f, 0f);
            ball.transform.localPosition = this.midel.transform.position;
            ball.transform.localRotation = this.transform.localRotation;
            ball.transform.parent = ParentBall.transform;
            //// arrow.AddComponent<SphereCollider>();
            //// transmit a reference to the arrow script
            ball.GetComponent<Ball>().SetCatapault(gameObject);
            //arrow.GetComponent<rotateArrow>().Setcamera(camera9);
            ballshoot = false;
            ballPrepared = false;
            //// subtract one arrow
            //arrows--;
       
    }


    public void prepareArrow()
    {
        //if(BallClicked)
        mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        if (ballshoot == false)
        {

            ball.transform.position = new Vector3(mousePosition.x, mousePosition.y, -9f);
           // Debug.Log(ball.transform.position);
            bowStringLinerenderer.SetPosition(1, ball.transform.position);
            posX = ball.transform.position.x;
            posY = ball.transform.position.y;
            //// determine the position on the screen
            //posX = this.rayHit.point.x;
            //posY = this.rayHit.point.y;
            //// set the bows angle to the arrow
            //Vector2 mousePos = new Vector2(transform.position.x - posX, transform.position.y - posY);
            //float angleZ = Mathf.Atan2(mousePos.y, mousePos.x);
            //transform.eulerAngles = new Vector3(0, 0, 0);
            //// determine the arrow pullout
            //length1 = mousePos.magnitude / 30f;
            //// length2 = mousePos.y / 15f;
            ////length1 = Mathf.Clamp(length1, 0, 0.5f);
            //// length2 = Mathf.Clamp(0, length2, 1);
            ////Debug.Log("lenghmmmmmmmmt1========="+ midel.transform.position.y);
            ////Debug.Log("lassssssss" + lastpossition.transform.position.y);
            ////   Debug.Log("mouse" + mousePos.y);
            //// set the bowstrings line renderer
            //if (mousePos.y > midel.transform.position.y)
            //{
            //    //Debug.Log("mouse" + mousePos.y);
            //    //  Debug.Log("lenghmmmmmmmmt1=========" + midel.transform.position.y);
            //    // if (mousePos.y < lastpossition.transform.position.y)
            //    stringPullout = new Vector3(-mousePos.x, -mousePos.y, -2f);
            //}
            //if (mousePos.y < lastpossition.transform.position.y)
            //{
            //    //Debug.Log("mouse" + mousePos.y)
            //    //Debug.Log("lassssssss" + lastpossition.transform.position.y);
            //}
            //// set the arrows position
            //Vector3 arrowPosition = stringPullout;
            //arrowPosition.y = (arrowPosition.y + 0.5f);
            //arrow.transform.localPosition = arrowPosition;
            //arrow.transform.rotation = Quaternion.Euler(0, 0, angleZ);
            //// Debug.Log(arrow.transform.rotation);
        }
        ballPrepared = true;
    }

    public void shootBall()
    {
        //
     //   Debug.Log("hjhjhjhjhjhjhjj");
            ballshoot = true;
        //  ball.AddComponent<Rigidbody2D>();
        //  Debug.Log(posX);
        rb = ball.GetComponent<Rigidbody2D>();
        //ball.GetComponent<Rigidbody>().angularDrag = 0.1f;
        //    ball.GetComponent<Rigidbody>().mass = 0.1f;
        //ball.GetComponent<Rigidbody>().useGravity = false;
        ////  arrow.transform.parent = gameManager.transform;
        //  rb.AddForce(transform.up * -posY*200f);
        rb.velocity = new Vector2(0, 5*(-posY-1f));
        //Debug.Log("rrr"+(-posY-3f));
        rb.AddForce(transform.right * -posX * 1000f);
        rb.AddForce(transform.right * posX * 500f);
        //Debug.Log(posX);
        //if (posX > 0)
        //ball.GetComponent<Rigidbody>().AddForce(Quaternion.Euler(new Vector3(transform.rotation.eulerAngles.x, 0, 0)) * new Vector3(12f * -posX, -posY * 4f, 0), ForceMode.VelocityChange);
        //else if (posX < 0)
        //ball.GetComponent<Rigidbody>().AddForce(Quaternion.Euler(new Vector3(transform.rotation.eulerAngles.x, 0, 0)) * new Vector3(12f * -posX, -posY * 4f, 0), ForceMode.VelocityChange);

        //  ball.GetComponent<Rigidbody2D>().AddForce(Quaternion.Euler(new Vector2(transform.rotation.eulerAngles.x, 0)) * new Vector3(12f * -posX, -posY * 4f), ForceMode.VelocityChange);

        //  }
        ballshoot = false;
        //  stringPullout = stringRestPosition;

        // Cam

        bowStringLinerenderer.SetPosition(1, bowStringPosition[1]);
    }



}
